export class Merchant{
  id:number;
  firstName:string;
  lastName:string;
  email:string;
  password:string;
  contact:string;
  isActive:string;

}
