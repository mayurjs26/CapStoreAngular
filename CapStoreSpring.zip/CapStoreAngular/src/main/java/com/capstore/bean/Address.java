/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.3
 */
package com.capstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "address")
@SequenceGenerator(name = "adrseq", sequenceName = "address_seq", initialValue=101)
public class Address {

	@Id
	@Column(name = "address_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "adrseq")
	private int id;

	@Column(name = "address_line1", length = 50)
	private String addLine1;

	@Column(name = "address_line2", length = 50)
	private String addLine2;

	@Column(name = "state", length = 25)
	private String state;

	@Column(name = "city", length = 25)
	private String city;
	@Column(name = "postal_code", length = 10)
	private long postalCode;

	/************** Relationships ******************/

	@JsonBackReference(value="customer-address")
	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customerFromAddress;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getAddLine1() {
		return addLine1;
	}

	public void setAddLine1(String addLine1) {
		this.addLine1 = addLine1;
	}

	public String getAddLine2() {
		return addLine2;
	}

	public void setAddLine2(String addLine2) {
		this.addLine2 = addLine2;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public long getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(long postalCode) {
		this.postalCode = postalCode;
	}

	@JsonIgnore
	public Customer getCustomer() {
		return customerFromAddress;
	}

	public void setCustomer(Customer customer) {
		this.customerFromAddress = customer;
	}

}
