/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "cart")
@SequenceGenerator(name = "cartseq", sequenceName = "cart_seq", initialValue = 101)
public class Cart {

	@Id
	@Column(name = "cart_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cartseq")
	private int id;

	/************** Relationships ******************/
	@OneToOne(cascade = CascadeType.PERSIST)
	@JoinColumn(name = "customer_id")
	private Customer customerFromCart;

	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name = "cart_product", joinColumns = { @JoinColumn(name = "cart_id") }, inverseJoinColumns = {
			@JoinColumn(name = "product_id") })
	private List<Product> product = new ArrayList<Product>();

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@JsonIgnore
	public Customer getCustomerFromCart() {
		return customerFromCart;
	}

	public void setCustomerFromCart(Customer customerFromCart) {
		this.customerFromCart = customerFromCart;
	}

	@JsonIgnore
	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public void addProduct(Product product) {
		this.getProduct().add(product);
	}

}
