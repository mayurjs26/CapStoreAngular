/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "coupons")
@SequenceGenerator(name = "cpnseq", sequenceName = "coupon_seq", initialValue = 101)
public class Coupon {
	@Id
	@Column(name = "coupon_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "cpnseq")

	private int id;

	@Column(name = "coupon_code", length = 15)
	private String couponCode;

	@Column(name = "product_discount")
	private double discountPrice;

	@Column(name = "expiry_date", length = 10)
	private String expiryDate;

	@Column(name = "is_used", length = 3)
	private String isUsed;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCouponCode() {
		return couponCode;
	}

	public void setCouponCode(String couponCode) {
		this.couponCode = couponCode;
	}

	public double getDiscountPrice() {
		return discountPrice;
	}

	public void setDiscountPrice(double discountPrice) {
		this.discountPrice = discountPrice;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public String getIsUsed() {
		return isUsed;
	}

	public void setIsUsed(String isUsed) {
		this.isUsed = isUsed;
	}

	@JsonIgnore
	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	/************** Relationships ******************/
	@OneToOne
	@JoinColumn(name = "product_id")
	private Product product;

}
