/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.3
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "cap_order")
@SequenceGenerator(name = "orderseq", sequenceName = "order_seq", initialValue = 101)
public class Order {

	@Id
	@Column(name = "order_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "orderseq")
	private int id;

	@Column(name = "order_date", length = 10)
	private String date;

	@Column(name = "order_amount")
	private double amount;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@JsonIgnore
	public Customer getCustomerFromOrder() {
		return customerFromOrder;
	}

	public void setCustomerFromOrder(Customer customer) {
		this.customerFromOrder = customer;
	}

	@JsonIgnore
	public List<Product> getProducts() {
		return products;
	}

	public void setProducts(List<Product> products) {
		this.products = products;
	}

	public void addProduct(Product Product) {
		this.getProducts().add(Product);
	}

	/************** Relationships ******************/
	@JsonBackReference(value = "customer-order")
	@ManyToOne
	@JoinColumn(name = "customer_id")
	private Customer customerFromOrder;

	@ManyToMany
	@JoinTable(name = "order_Product", joinColumns = { @JoinColumn(name = "order_id") }, inverseJoinColumns = {
			@JoinColumn(name = "product_id") })
	private List<Product> products = new ArrayList<Product>();

	@OneToOne
	@JoinColumn(name = "address_id")
	private Address addressFromOrder;

	@OneToOne
	@JoinColumn(name = "coupon_id")
	private Coupon couponFromOrder;
	
	
}
