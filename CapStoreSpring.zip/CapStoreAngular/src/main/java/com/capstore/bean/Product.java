/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.3
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import com.fasterxml.jackson.annotation.JsonBackReference;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "product")
@SequenceGenerator(name = "pseq", sequenceName = "product_seq", initialValue=101)
public class Product {
	@Id
	@Column(name = "product_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator="pseq")
	private int id;

	@Column(name = "product_name", length = 50)
	private String name;

	@Column(name = "product_brand", length = 50)
	private String brand;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@JsonIgnore
	public Category getCategory() {
		return categoryFromProduct;
	}

	public void setCategory(Category category) {
		this.categoryFromProduct = category;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getBrand() {
		return brand;
	}

	public void setBrand(String brand) {
		this.brand = brand;
	}

	@JsonIgnore
	public List<Inventory> getInventory() {
		return inventoryFromProduct;
	}

	public void setInventory(List<Inventory> inventory) {
		this.inventoryFromProduct = inventory;
	}

	public void addInventory(Inventory inventory) {
		inventory.setProduct(this);
		this.getInventory().add(inventory);
	}

	@JsonIgnore
	public List<Review> getReview() {
		return reviewFromProduct;
	}

	public void setReview(List<Review> review) {
		this.reviewFromProduct = review;
	}

	public void addReview(Review review) {
		review.setProduct(this);
		this.getReview().add(review);
	}

	@JsonIgnore
	public List<Image> getImageFromProduct() {
		return imageFromProduct;
	}

	public void setImageFromProduct(List<Image> imageFromProduct) {
		this.imageFromProduct = imageFromProduct;
	}

	public void addImage(Image image) {
		image.setProductFromImage(this);
		this.getImageFromProduct().add(image);
	}

	public MostView getMostView() {
		return mostView;
	}

	public void setMostView(MostView mostView) {
		this.mostView = mostView;
	}

	/************** Relationships ******************/

	@JsonBackReference(value = "product-category")
	@ManyToOne
	@JoinColumn(name = "category_id")
	private Category categoryFromProduct;

	@JsonIgnore
	@JsonManagedReference(value = "product-inventory")
	@OneToMany(mappedBy = "productFromInventory", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Inventory> inventoryFromProduct = new ArrayList<Inventory>();

	@JsonManagedReference(value = "product-review")
	@OneToMany(mappedBy = "productFromReview", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Review> reviewFromProduct = new ArrayList<Review>();

	@JsonManagedReference(value = "product-image")
	@OneToMany(mappedBy = "productFromImage", fetch = FetchType.LAZY, cascade = CascadeType.ALL)
	private List<Image> imageFromProduct = new ArrayList<Image>();

	@JsonIgnore
	@OneToOne(mappedBy = "productFromMostView", cascade = CascadeType.ALL)
	private MostView mostView;
}
