/*
 * Author :- Mayuresh Shinde 173560
 * version:- 1.0.2
 */
package com.capstore.bean;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.fasterxml.jackson.annotation.JsonIgnore;

@Entity
@Table(name = "wishlist")
@SequenceGenerator(name = "wlseq", sequenceName = "wishlist_seq", initialValue = 101)
public class WishList {

	@Id
	@Column(name = "wishlist_id", length = 10)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "wlseq")
	private int id;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@JsonIgnore
	public List<Product> getProduct() {
		return product;
	}

	public void setProduct(List<Product> product) {
		this.product = product;
	}

	public Customer getCustomer() {
		return customerFromWishList;
	}

	public void setCustomer(Customer customer) {
		this.customerFromWishList = customer;
	}

	@JsonIgnore
	public Customer getCustomerFromWishList() {
		return customerFromWishList;
	}

	public void setCustomerFromWishList(Customer customerFromWishList) {
		this.customerFromWishList = customerFromWishList;
	}

	public void addProduct(Product product) {
		this.getProduct().add(product);
	}

	/************** Relationships ******************/
	@ManyToMany
	@JoinTable(name = "product_wishlist", joinColumns = { @JoinColumn(name = "wishlist_id") }, inverseJoinColumns = {
			@JoinColumn(name = "product_id") })
	private List<Product> product = new ArrayList<Product>();

	@OneToOne
	@JoinColumn(name = "customer_id")
	private Customer customerFromWishList;
}
