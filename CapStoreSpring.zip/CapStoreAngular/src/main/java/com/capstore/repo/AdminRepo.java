package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Admin;

@Repository
public interface AdminRepo extends CrudRepository<Admin, Integer>{

}
