package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Category;
import com.capstore.bean.Customer;

@Repository
public interface CategoryRepo extends CrudRepository<Category, Integer>{

}
