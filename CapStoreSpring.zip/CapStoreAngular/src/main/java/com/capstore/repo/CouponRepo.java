package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Coupon;

@Repository
public interface CouponRepo extends CrudRepository<Coupon, Integer>{

}
