package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Customer;
import com.capstore.bean.Merchant;

@Repository
public interface MerchantRepo extends CrudRepository<Merchant, Integer>{

}
