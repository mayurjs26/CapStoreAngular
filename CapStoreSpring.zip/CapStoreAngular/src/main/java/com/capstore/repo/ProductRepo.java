package com.capstore.repo;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Customer;
import com.capstore.bean.MostView;
import com.capstore.bean.Product;

@Repository
public interface ProductRepo extends CrudRepository<Product, Integer>{
	
//	@Query(value="SELECT p.product_name,m.sold_count FROM product p INNER JOIN most_viewed m on p.product_id = m.product_id")
//	public List<> mostByProduct();

}
