package com.capstore.repo;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capstore.bean.Customer;
import com.capstore.bean.Review;

@Repository
public interface ReviewRepo extends CrudRepository<Review, Integer>{

}
