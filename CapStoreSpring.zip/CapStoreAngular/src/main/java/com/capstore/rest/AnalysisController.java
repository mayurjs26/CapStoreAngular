package com.capstore.rest;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capstore.bean.Address;
import com.capstore.bean.Admin;
import com.capstore.bean.Cart;
import com.capstore.bean.Category;
import com.capstore.bean.Coupon;
import com.capstore.bean.Customer;
import com.capstore.bean.Image;
import com.capstore.bean.Inventory;
import com.capstore.bean.Merchant;
import com.capstore.bean.MostView;
import com.capstore.bean.Order;
import com.capstore.bean.Product;
import com.capstore.bean.Review;
import com.capstore.bean.WishList;
import com.capstore.repo.AdminRepo;
import com.capstore.repo.CartRepo;
import com.capstore.repo.CategoryRepo;
import com.capstore.repo.CouponRepo;
import com.capstore.repo.CustomerRepo;
import com.capstore.repo.ImageRepo;
import com.capstore.repo.InventoryRepo;
import com.capstore.repo.MerchantRepo;
import com.capstore.repo.MostViewRepo;
import com.capstore.repo.OrderRepo;
import com.capstore.repo.ProductRepo;
import com.capstore.repo.ReviewRepo;
import com.capstore.repo.WishListRepo;

@RestController
@CrossOrigin(origins="http://localhost:4200")
public class AnalysisController {

	@Autowired
	AdminRepo adminRepo;
	@Autowired
	CartRepo cartRepo;
	@Autowired
	CategoryRepo categoryRepo;
	@Autowired
	CouponRepo couponRepo;
	@Autowired
	CustomerRepo custRepo;
	@Autowired
	ImageRepo imageRepo;
	@Autowired
	InventoryRepo inventoryRepo;
	@Autowired
	MerchantRepo merchantRepo;
	@Autowired
	MostViewRepo mostViewRepo;
	@Autowired
	OrderRepo orderRepo;
	@Autowired
	ProductRepo productRepo;
	@Autowired
	ReviewRepo reviewRepo;
	@Autowired
	WishListRepo wishListRepo;

//
	@GetMapping(path = "/productofmerchant/{merchantid}")
	public List<Product> getAllProductOfMerchant(@PathVariable("merchantid") int merchantId) {
		Merchant merchant = merchantRepo.findById(merchantId).get();
		Iterable<Inventory> inv = merchant.getInventory();
		List<Product> products = new ArrayList<Product>();
		for (Inventory inventory : inv) {
			products.add(inventory.getProduct());
		}
		return products;
	}
//
	@GetMapping(path = "/productsoldgraph")
	public List<MostView> getAllMostViewed() {
		List<MostView> mv = (List<MostView>) mostViewRepo.findAll();
		return mv;

	}
//
	@GetMapping(path = "/allorders")
	public List<Order> getAllOrder() {
		return (List<Order>) orderRepo.findAll();

	}
//
	@GetMapping(path = "/viewbyproduct")
	public Iterable<MostView> viewByProduct() {
		// Iterable<Product> products = productRepo.findAll();
		Iterable<MostView> mostViews = mostViewRepo.findAll();
		return mostViews;
	}
	
	
}
