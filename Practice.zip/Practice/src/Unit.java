
class Unit {

	
	public static void main(String[] args) {
		
		int unit = 45678%10;
		
		System.out.println(unit);
	}
}
